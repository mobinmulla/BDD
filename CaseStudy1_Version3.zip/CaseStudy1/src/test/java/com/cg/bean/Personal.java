package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	@FindBy(tagName="a")
	private WebElement button;
	
	@FindBy(id="txtFirstName")
	private WebElement firstname; 
	
	@FindBy(id="txtLastName")
	private WebElement lastname; 

	@FindBy(id="txtEmail")
	private WebElement email; 
	
	@FindBy(id="txtPhone")
	private WebElement phone;
	
	@FindBy(id="address1")
	private WebElement address1; 
	
	@FindBy(id="address2")
	private WebElement address2; 

	@FindBy(id="city")
	private WebElement city; 
	
	@FindBy(id="state")
	private WebElement state;
	
	public void button() {
		button.click();
	}
	
	public String getFirstname() {
		return firstname.getAttribute("value");
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getLastname() {
		return lastname.getAttribute("value");
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	
	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public String getAddress1() {
		return address1.getAttribute("value");
	}

	public void setAddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public String getAddress2() {
		return address2.getAttribute("value");
	}

	public void setAddress2(String address2) {
		this.address2.sendKeys(address2);
	}

	public void city(int cindex) {
		Select select = new Select(city);
		select.selectByIndex(cindex);
	}
	
	public void state(int sindex) {
		Select select = new Select(state);
		select.selectByIndex(sindex);
	}
	
}
