package com.cg.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/resources/feature1/personal.feature","src/test/resources/feature2/eduction.feature"},
		glue = { "com.cg.step" }
		
		)
public class TestRunner {

}
