package com.cg.step;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {
	
	WebDriver driver;
	Personal person;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver/chromedriver.exe");
	}
	
	
	
	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		driver = new ChromeDriver();
		person = new Personal();
		PageFactory.initElements(driver, person);
		driver.get("C:\\Users\\mobmulla\\Desktop\\BDD\\CaseStudy1\\html\\personalDetails.html");
	}

	@Then("^validate title$")
	public void validate_title() throws Throwable {
	       JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;
			if (driver.getTitle().equals("Personal Details")) {
				Thread.sleep(2000);
				scriptExecutor.executeScript("alert('you are on correct page!')");
				try {
				Thread.sleep(2000); } catch (InterruptedException e) {e.printStackTrace();}		
				Alert alert = driver.switchTo().alert();
				alert.accept();
			} else {
				scriptExecutor.executeScript("alert('Wrong page!')");
				Alert alert = driver.switchTo().alert();
				alert.accept();
				driver.quit();
			}
	}

	@When("^invalid first name$")
	public void invalid_first_name() throws Throwable {
		person.setFirstname("");//blank
	     
	}

	@Then("^validation$")
	public void validation() throws Throwable {
		person.button();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.quit();
	     
	}

	@When("^invalid last name$")
	public void invalid_last_name() throws Throwable {
		person.setFirstname("Mobin");
	     
	}

	@When("^invalid email$")
	public void invalid_email() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
	     
	}

	@When("^invalid contact$")
	public void invalid_contact() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("1234596587");
	     
	}

	@When("^invalid address one$")
	public void invalid_address_one() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("9270523563");
		person.setAddress1("");
	        
	     
	}

	@When("^invalid address two$")
	public void invalid_address_two() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("9270523563");
		person.setAddress1("Airoli");
	    person.setAddress2("");
	     
	}

	@When("^invalid city$")
	public void invalid_city() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("9270523563");
		person.setAddress1("Airoli");
	    person.setAddress2("Mumbai");
	    person.city(0);
	     
	}

	@When("^invalid state$")
	public void invalid_state() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("9270523563");
		person.setAddress1("Airoli");
	    person.setAddress2("Mumbai");
	    person.city(1);
	    person.state(0);
	    
	     
	}

	@When("^right inputs$")
	public void right_inputs() throws Throwable {
		person.setFirstname("Mobin");
		person.setLastname("Mulla");
		person.setEmail("ab@gmail.com");
		person.setPhone("9270523563");
		person.setAddress1("Airoli");
	    person.setAddress2("Mumbai");
	    person.city(1);
	    person.state(1);
	     
	}
	
	@Then("^page change$")
	public void page_change() throws Throwable {
		person.button();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(8000);
		driver.quit();
	     
	}


}
