package com.cg.step;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Eduction;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;

public class EductionStepDefination {
	WebDriver driver;
	Eduction education;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver/chromedriver.exe");
	}
	

	@Given("^user is on education page$")
	public void user_is_on_education_page() throws Throwable {
		driver = new ChromeDriver();
		education = new Eduction();
		PageFactory.initElements(driver, education);
		driver.get("C:\\Users\\mobmulla\\Desktop\\BDD\\CaseStudy1\\html\\educationDetails.html");
	     
	}

	@Then("^education title validate title$")
	public void education_title_validate_title() throws Throwable {
		JavascriptExecutor scriptExecutor = (JavascriptExecutor) driver;
		if (driver.getTitle().equals("Eduction Details")) {
			
			Thread.sleep(2000);
			scriptExecutor.executeScript("alert('you are on correct page!')");
			try {
			Thread.sleep(2000); } catch (InterruptedException e) {e.printStackTrace();}		
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} else {
			
			scriptExecutor.executeScript("alert('Wrong page!')");
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} 
	      
	}

	@When("^invalid graduation$")
	public void invalid_graduation() throws Throwable {
	     education.graduation(0);
	      
	}

	@Then("^Graduation validation$")
	public void graduation_validation() throws Throwable {
	     education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.quit();
	}

	@When("^invalid percent$")
	public void invalid_percent() throws Throwable {
	     education.graduation(1);
	     education.setPercentage("");
	      
	}

	@Then("^Percentage validation$")
	public void percentage_validation() throws Throwable {
		 education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.quit();
	      
	}

	@When("^invalid passing year$")
	public void invalid_passing_year() throws Throwable {
		education.graduation(1);
	     education.setPercentage("56");
	     education.setPassingYear("");
	      
	}

	@Then("^passing year validation$")
	public void passing_year_validation() throws Throwable {
		education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000);
	     driver.quit();
	      
	}

	@When("^invalid project name$")
	public void invalid_project_name() throws Throwable {
		education.graduation(1);
	     education.setPercentage("56");
	     education.setPassingYear("2015");
	     education.setProjectName("");	      
	}

	@Then("^Project validation$")
	public void project_validation() throws Throwable {
		 education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.quit();
	      
	}

	@When("^invalid technology$")
	public void invalid_technology() throws Throwable {
		education.graduation(1);
	     education.setPercentage("56");
	     education.setPassingYear("2015");
	     education.setProjectName("Abcd");
	     education.technology(0);
	      
	}

	@Then("^Technology validation$")
	public void technology_validation() throws Throwable {
		 education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.quit();
	      
	}

	@When("^other technology invalid details$")
	public void other_technology_invalid_details() throws Throwable {
		education.graduation(1);
	     education.setPercentage("56");
	     education.setPassingYear("2015");
	     education.setProjectName("Abcd");
	     education.technology(5);
	      
	}

	@Then("^Other Details validation$")
	public void other_Details_validation() throws Throwable {
	     
		 education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.quit();
	}

	@When("^valid all details$")
	public void valid_all_details() throws Throwable {
		education.graduation(1);
	     education.setPercentage("56");
	     education.setPassingYear("2015");
	     education.setProjectName("Abcd");
	     education.technology(5);
	     education.setOthertech("C");
	      
	}

	@Then("^validation successfully$")
	public void validation_successfully() throws Throwable {
		 education.button();
	     Thread.sleep(1000);
	     driver.switchTo().alert().accept();
	     Thread.sleep(1000); 
	     driver.navigate().to("C:\\Users\\mobmulla\\Desktop\\BDD\\CaseStudy1\\html\\personalDetails.html");
	     driver.quit();
	}    

}
