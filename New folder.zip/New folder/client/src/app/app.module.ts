import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { ChatService } from 'chat.service';
import { Routes, RouterModule } from "@angular/router";
import { ChatboxComponent } from './chatbox/chatbox.component';




const routes: Routes = [
  {path: '',redirectTo:'/home',pathMatch:'full'},
  {path:'chat', component: ChatboxComponent  }
];

@NgModule({
  declarations: [
    AppComponent,
    ChatboxComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ChatService],
  bootstrap: [AppComponent]
})
export class AppModule { }
