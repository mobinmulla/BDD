package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Eduction {

	@FindBy(tagName="a")
	private WebElement nextButton;

	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingYear")
	private WebElement passingYear;

	@FindBy(id = "projectName")
	private WebElement projectName;

	@FindBy(id = "technology")
	private WebElement technology;

	@FindBy(id = "otherTech")
	private WebElement othertech;

	public void button() {
		nextButton.click();
	}

	public void graduation(int index) {
		Select select = new Select(graduation);
		select.selectByIndex(index);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public void technology(int index) {
		Select select = new Select(technology);
		select.selectByIndex(index);
	}

	public String getProjectName() {
		return projectName.getAttribute("value");
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public String getOthertech() {
		return othertech.getAttribute("value");
	}

	public void setOthertech(String othertech) {
		this.othertech.sendKeys(othertech);
	}
}
